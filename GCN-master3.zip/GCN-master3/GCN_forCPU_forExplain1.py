#导入库
from rdkit import Chem
from rdkit.Chem.Crippen import MolLogP
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem.Draw import SimilarityMaps
from rdkit.Chem.Draw.MolDrawing import MolDrawing, DrawingOptions
from rdkit.Chem.Draw import rdMolDraw2D
import numpy as np
import torch
import time

import csv
import collections

def readCSV(file_name,column_index,data_type):
    """
    读取CSV文件
    """
    
    CSV = csv.reader(open(file_name,'r'))
    
    
    if data_type=="str":
        data = list( map ( lambda x:  x[column_index],CSV )  )
        return data[1:]
    if data_type=="float":
        data = list( map ( lambda x:  x[column_index],CSV )  )
        data = data[1:]
        data = list( map ( lambda x: float(x),data ))
        return data


def PRDkitMolLogP(smile,save_name):
    """
    计算LogP
    """
    m = Chem.MolFromSmiles(smile)
    logp = MolLogP(m)
    contribs = rdMolDescriptors._CalcCrippenContribs(m)
    #fig = SimilarityMaps.GetSimilarityMapFromWeights(m, [x for x,y in contribs],, contourLines=10)
    #fig.savefig(save_name)

    atoms = m.GetNumAtoms()
    atom_list = list(range(atoms))
    atom_cols = {}
    atom_cols_list=[]


    x_with_w = np.array([x for x,y in contribs])
    x_with_w_norm = (x_with_w-x_with_w.min(0))/(x_with_w.max(0)-x_with_w.min(0))
    for index ,i in enumerate(x_with_w_norm):
        atom_cols[index] = (i,1-i,1-i)
        atom_cols_list.append([i,1-i,1-i])
    #print(dir(rdMolDraw2D))
    d = rdMolDraw2D.MolDraw2DCairo(500, 500)
    print("-----------------------")
    rdMolDraw2D.PrepareAndDrawMolecule(d,m,highlightAtoms=atom_list,highlightAtomColors=atom_cols)

    with open(save_name+".jpg", 'wb') as f:
        f.write(d.GetDrawingText())
    
    return logp



smiles =  readCSV('trainMol.csv',1,"str")
Y = readCSV('trainMol.csv',3,"float")
#smiles_property_dir = collections.OrderedDict(list(zip(smiles,Y)))

max_natoms = 80
num_data = 50000
#载入数据
##########################
#max_natoms = 50
#with open('smiles.txt') as f:
  #smiles = f.readlines()[:]
  #smiles = [s.strip() for s in smiles]
  #smiles = [s.split()[1] for s in smiles]
  #smiles = [s for s in smiles[:30000] if Chem.MolFromSmiles(s).GetNumAtoms()<50]

#print ('Number of smiles:', len(smiles))

#计算分子指纹和描述符

#Y = []
#num_data = 20000
#st = time.time()
#for s in smiles[:num_data]:
  #m = Chem.MolFromSmiles(s)
  #logp = MolLogP(m)
  #Y.append(logp)
#end = time.time()
#print (f'Time:{(end-st):.3f}')


###########################




#数据批处理

#Dataset
from torch.utils.data import Dataset, DataLoader
from rdkit.Chem.rdmolops import GetAdjacencyMatrix
class MolDataset(Dataset):

    def __init__(self, smiles, properties, max_natoms, normalize_A=False):

      self.smiles = smiles

      self.properties = properties

      self.max_natoms = max_natoms

      

    def __len__(self):

        return len(self.smiles)

    def __getitem__(self, idx):

        s = self.smiles[idx]

        m = Chem.MolFromSmiles(s)

        natoms = m.GetNumAtoms()
        #from plot_mol import  plot_mol_with_index(m)

        #adjacency matrix

        A = GetAdjacencyMatrix(m) + np.eye(natoms)
        #print(A)
        #print(A.shape)
########################################################
        #D = np.array(np.sum(A, axis=0))
        #print(D)
        #print(D.shape)
        
        #D = np.matrix(np.diag(D))
        #print(D.shape)
        
        #A = D**-1*A
        #print(A.shape)
        #input()
########################################################
        A_padding = np.zeros((self.max_natoms, self.max_natoms))        

        A_padding[:natoms,:natoms] = A

        A_padding = torch.from_numpy(A_padding)
        


        #atom feature

        X = [self.atom_feature(m,i) for i in range(natoms)]



        for i in range(natoms, max_natoms):

            X.append(np.zeros(28))

        X = np.array(X)

        sample = dict()

        sample['X'] = torch.from_numpy(X)

        sample['A'] = A_padding

        sample['Y'] = self.properties[idx]

        sample["smi"] = s

 

        return sample

 

    def normalize_A(A):

      #D = dfadfa(A)

      #A = D*DD
      

      return A

 

    def one_of_k_encoding(self, x, allowable_set):

        if x not in allowable_set:

            raise Exception("input {0} not in allowable set{1}:".format(x, allowable_set))

        #print list((map(lambda s: x == s, allowable_set)))

        return list(map(lambda s: x == s, allowable_set))

 

    def one_of_k_encoding_unk(self, x, allowable_set):

        """Maps inputs not in the allowable set to the last element."""

        if x not in allowable_set:

            x = allowable_set[-1]

        return list(map(lambda s: x == s, allowable_set))

 

    def atom_feature(self, m, atom_i):

 

        atom = m.GetAtomWithIdx(atom_i)

        return np.array(
                        self.one_of_k_encoding_unk(atom.GetSymbol(),['C', 'N', 'O', 'S', 'F', 'P', 'Cl', 'Br', 'B', 'H']) +

                        self.one_of_k_encoding(atom.GetDegree(), [0, 1, 2, 3, 4, 5]) +

                        self.one_of_k_encoding_unk(atom.GetTotalNumHs(), [0, 1, 2, 3, 4]) +

                        self.one_of_k_encoding_unk(atom.GetImplicitValence(), [0, 1, 2, 3, 4, 5]) +

                        [atom.GetIsAromatic()])    # (10, 6, 5, 6, 1) --> total 28


#定义图卷积模型

#Model
import torch
import torch.nn as nn
import torch.nn.functional as F
 

class GConvRegressor(torch.nn.Module):

  def __init__(self, n_feature=128, n_layer = 10):

    super(GConvRegressor, self).__init__()

    self.W = nn.ModuleList([nn.Linear(n_feature, n_feature) for _ in range(n_layer)])

    self.embedding = nn.Linear(28, n_feature)

    self.dropout = nn.Dropout2d(0.5)

    self.fc = nn.Linear(n_feature, 1)

 

  def forward(self, x, A):

 

    x = self.embedding(x)


    for l in self.W:

      x = l(x)

      x = torch.einsum('ijk,ikl->ijl', (A.clone(), x))

      x = F.relu(x)
    
    x = x.mean(1)
    #print(x)
    #x = torch.max(x,1)[0]

 
    #print(x.size())
    #input()
    x= self.dropout(x)
    
    retval = self.fc(x)

    return retval


#训练模型
#Train model
import time
lr = 1e-4
model = GConvRegressor(128, 5) 

#model initialize
for param in model.parameters():
    if param.dim() == 1:
        continue
        nn.init.constant(param, 0)
    else:
        nn.init.xavier_normal_(param)

#Dataset
train_smiles = smiles[:45000]
test_smiles = smiles[45000:50000]
train_logp = Y[:45000]
test_logp = Y[45000:50000]
train_dataset = MolDataset(train_smiles, train_logp, max_natoms)
test_dataset = MolDataset(test_smiles, test_logp, max_natoms)

#Dataloader
train_dataloader = DataLoader(train_dataset, batch_size=128, num_workers=0)
test_dataloader = DataLoader(test_dataset, batch_size=128, num_workers=0)

optimizer = torch.optim.Adam(model.parameters(), lr=lr)
#optimizer = torch.optim.SGD(model.parameters(), lr=lr)

loss_fn = nn.MSELoss()
loss_list = []
def train():

    st = time.time()
    for epoch in range(30):
        epoch_loss = []
        for i_batch, batch in enumerate(train_dataloader):
            x, y, A = \
                batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            pred = model(x, A).squeeze(-1)
            loss = loss_fn(pred, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            optimizer.step()
            loss_list.append(loss.data.cpu().numpy())
            epoch_loss.append(loss.data.cpu().numpy())

        if True: print (epoch, np.mean(np.array(epoch_loss)))
    end = time.time()
    print ('Time:', end-st)

#保存模型

#Save model
    fn = 'save.pt'
    torch.save(model.state_dict(), fn)
train()









def test():
#加载模型
#Load model
    fn = 'save.pt'
    model.load_state_dict(torch.load(fn))
#绘制损失曲线    
    import matplotlib.pyplot as plt

    plt.plot(loss_list)
    plt.xlabel('Num iteration')
    plt.ylabel('Loss')

#测试模型
#Test model
    model.eval()
    with torch.no_grad():
        y_pred_train, y_pred_test = [], []
        loss_train, loss_test = [], []
        pred_train, pred_test = [], []
        true_train, true_test = [], []

  
        for batch in train_dataloader:
            x, y, A = \
                batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            pred = model(x, A).squeeze(-1)
            pred_train.append(pred.data.cpu().numpy())
            true_train.append(y.data.cpu().numpy())

            loss_train.append(loss_fn(y, pred).data.cpu().numpy())
  
        for batch in test_dataloader:
            x, y, A = \
                batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            #print(" x, y, A", x, y, A)
            pred = model(x, A).squeeze(-1)
            pred_test.append(pred.data.cpu().numpy())
            true_test.append(y.data.cpu().numpy())
            loss_test.append(loss_fn(y, pred).data.cpu().numpy())

    pred_train = np.concatenate(pred_train, -1)
    pred_test = np.concatenate(pred_test, -1)
    true_train = np.concatenate(true_train, -1)
    true_test = np.concatenate(true_test, -1)
    
    print ('Train loss:', np.mean(np.array(loss_train)))
    print ('Test loss:', np.mean(np.array(loss_test)))

    #绘图
    plt.scatter(true_train, pred_train, s=1)
    plt.scatter(true_test, pred_test, s=1)

    plt.plot([-8,12], [-8,12])
    plt.xlabel('True')
    plt.ylabel('Pred')
    plt.show()


test()


def predict_smi(smi,model_name,save_fig_name):

    from  help_tools import get_mol_feature,get_mol_A_
    x = get_mol_feature(smi)
    A = get_mol_A_(smi)

    x_ = np.array(x).reshape([1,80,28])
    A_ = np.array(A).reshape([1,80,80])

    x_ = torch.from_numpy(x_).float()
    A_ = torch.from_numpy(A_).float()

    #print(A_.size())

    pred = model(x_, A_).squeeze(-1)
    print("pred",pred)


    fn =model_name
    model.load_state_dict(torch.load(fn))
    model.eval()
    #print(model)
    parm = {}
    for name,parameters in model.named_parameters():
        #print(name)
        parm[name] = parameters.detach().numpy()

    #print(parm["W.0.weight"].shape,parm["W.0.bias"].shape,parm["embedding.weight"].shape,x.shape,parm["fc.weight"].shape)
    x = x.dot(parm["embedding.weight"].T)+parm["embedding.bias"]
    x = A.dot(x.dot(parm["W.0.weight"].T)+parm["W.0.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.1.weight"].T)+parm["W.1.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.2.weight"].T)+parm["W.2.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.3.weight"].T)+parm["W.3.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.4.weight"].T)+parm["W.4.bias"])
    x = (abs(x) + x) / 2

    #x = np.mean(x,0)

    x_f = x*parm["fc.weight"][0]+parm["fc.bias"][0] #80_128*128 + 1
    #x_t = x*parm["fc.weight"][1]+parm["fc.bias"][1] #80_128*128 + 1
    x_f_with_w = np.sum(x_f,1) #80
    print("x_f_with_w ",x_f_with_w.shape)
    #x_t_with_w = np.sum(x_t,1) #80
    #x_with_w = x_t_with_w-x_f_with_w
    x_with_w = x_f_with_w
    x_with_w_norm = (x_with_w-x_with_w.min(0))/(x_with_w.max(0)-x_with_w.min(0))
    #print("x_with_w_norm",x_with_w_norm)
    from help_tools import  plot_mol_with_color
    plot_mol_with_color(smi,x_with_w_norm,"heat_map/"+save_fig_name+".png")
    

    #x = x.dot(parm["fc.weight"].T)+parm["fc.bias"]
    #print(x.shape,x)
    
    with torch.no_grad():
        x = get_mol_feature(smi)
        x = torch.from_numpy(x).float().view(1,80,28)
        A = torch.from_numpy(A).float().view(1,80,80)
      
        score = model(x, A).squeeze(-1).numpy()
        #print(score)
        return score#,np.where(score==np.max(score))[1]

smi,model_name,save_fig_name = "Cc1cc(C(=O)Nc2ccc(OCC(N)=O)cc2)c(C)n1C1CC1","save.pt","r"
predict_smi(smi,model_name,save_fig_name)
print(PRDkitMolLogP("Cc1cc(C(=O)Nc2ccc(OCC(N)=O)cc2)c(C)n1C1CC1","1"))

smiles =  readCSV('trainMol.csv',1,"str")
Y = readCSV('trainMol.csv',3,"float")

for index ,smile in enumerate(smiles[-10:]):
    model_name,save_fig_name = "save.pt",str(index)+"r"
    print(predict_smi(smile,model_name,save_fig_name))
    print(PRDkitMolLogP(smile,str(index)+"t"))
    
    





    
