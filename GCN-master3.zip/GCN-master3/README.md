# GCN
GCN

https://blog.csdn.net/u012325865/article/details/105765809

https://blog.csdn.net/u012325865/article/details/104821039

https://blog.csdn.net/u012325865/article/details/105762913


https://zhuanlan.zhihu.com/p/83456743

https://pubs.acs.org/doi/10.1021/acs.jmedchem.9b00959
https://drugai.blog.csdn.net/article/details/104868996
