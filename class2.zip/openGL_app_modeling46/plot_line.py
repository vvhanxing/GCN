
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
 
 
def drawFunc():



    glClearColor(0.0, 0.0, 0.0, 0.0)
    glClear(GL_COLOR_BUFFER_BIT)
 
    glColor3f(0.0, 1.0, 0.0)
    glLineWidth(2)
    glBegin(GL_LINES)
    glVertex3f(-0.5, -0.5, 0.0)
    glVertex3f(0.5, 0.5, 0.0)

    glEnd()
    

    glFlush()
 
if __name__ == '__main__':
    glutInit()
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA)
    glutInitWindowSize(400, 400)
    glutCreateWindow(b"First")
    glutDisplayFunc(drawFunc)
    glutMainLoop()
