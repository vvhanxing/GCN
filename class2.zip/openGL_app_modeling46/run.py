from viewer import Viewer
        

if __name__ == "__main__":

    file_name = "new1.mol2"

    viewer = Viewer(file_name)

    viewer.main_loop()
