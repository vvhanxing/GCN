# -*- coding: utf8 -*-
from OpenGL.GL import glCallList, glClear, glClearColor, glColorMaterial, glCullFace, glDepthFunc, glDisable, glEnable,\
                      glFlush, glGetFloatv, glLightfv, glLoadIdentity, glMatrixMode, glMultMatrixf, glPopMatrix, \
                      glPushMatrix, glTranslated, glViewport, \
                      GL_AMBIENT_AND_DIFFUSE, GL_BACK, GL_CULL_FACE, GL_COLOR_BUFFER_BIT, GL_COLOR_MATERIAL, \
                      GL_DEPTH_BUFFER_BIT, GL_DEPTH_TEST, GL_FRONT_AND_BACK, GL_LESS, GL_LIGHT0, GL_LIGHTING, \
                      GL_MODELVIEW, GL_MODELVIEW_MATRIX, GL_POSITION, GL_PROJECTION, GL_SPOT_DIRECTION
from OpenGL.constants import GLfloat_3, GLfloat_4
from OpenGL.GLU import gluPerspective, gluUnProject
from OpenGL.GLUT import glutCreateWindow, glutDisplayFunc, glutGet, glutInit, glutInitDisplayMode, \
                        glutInitWindowSize, glutMainLoop, \
                        GLUT_SINGLE, GLUT_RGB, GLUT_WINDOW_HEIGHT, GLUT_WINDOW_WIDTH



import numpy

from numpy.linalg import norm, inv

from interaction import Interaction

from primitive import init_primitives, G_OBJ_PLANE,G_OBJ_CYLINDER,G_OBJ_LINE

from node import Sphere, Cube, SnowFigure,Cylinder#

from scene import Scene

####
import color
import readmol
####

class Viewer(object):

    def __init__(self,file_name,atom_cols_list):

        """ Initialize the viewer. """

        self.file_name = file_name

        self.atom_cols_list = atom_cols_list

        self.init_interface()

        self.init_opengl()

        self.init_scene()

        self.init_interaction()

        init_primitives()
        



    def init_interface(self):

        """ initialize the window and register the render function """

        glutInit()

        glutInitWindowSize(640, 480)

        glutCreateWindow("3D Modeller")

        glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)

        glutDisplayFunc(self.render)



    def init_opengl(self):

        """ initialize the opengl settings to render the scene """

        self.inverseModelView = numpy.identity(4)

        self.modelView = numpy.identity(4)



        glEnable(GL_CULL_FACE)

        glCullFace(GL_BACK)

        glEnable(GL_DEPTH_TEST)

        glDepthFunc(GL_LESS)



        glEnable(GL_LIGHT0)

        glLightfv(GL_LIGHT0, GL_POSITION, GLfloat_4(0, 0, 1, 0))

        glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, GLfloat_3(0, 0, -1))



        glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)

        glEnable(GL_COLOR_MATERIAL)

        glClearColor(0.4, 0.4, 0.4, 0.0)





    def init_scene(self):

        """ initialize the scene object and initial scene """

        self.scene = Scene()

        self.create_sample_scene()



    def create_sample_scene(self):

        #cube_node = Cube()

        #cube_node.translate(2, 0, 2)
        
        #cube_node.rotate(0,0,0)

        #cube_node.scale_init(1.0,1.0,1.0)

        #cube_node.color_index = 1

        #self.scene.add_node(cube_node)

        
        #file_name = "new1.mol2"
        for cont ,  pos in enumerate(readmol.get_mol_info(self.file_name)[1]):
        
        

            sphere_node = Sphere()

            sphere_node.translate(pos[0], pos[1], pos[2])

            sphere_node.scale_init(1.5,1.5,1.5)

            if self.atom_cols_list==[]:
                
                sphere_node.color_index = readmol.get_mol_info(self.file_name)[0][str(cont+1)][1]*10

            else:
                
                color.COLORS["score"+str(cont)] = [0.8, 0.8, cont*0.1]

                sphere_node.color_index = "score"+str(cont)#readmol.get_mol_info(self.file_name)[0][str(cont+1)][1]*10

            self.scene.add_node(sphere_node)




        

        #hierarchical_node = SnowFigure()

        #hierarchical_node.translate(-2, 0, -2)

        #self.scene.add_node(hierarchical_node)

######################################2
        #cylinder_node = Cylinder()
        #cylinder_node.translate(0, 0, 0)#2
        #cylinder_node.rotate(0,0,0)
        #self.scene.add_node(cylinder_node)
######################################2


    def init_interaction(self):

        """ init user interaction and callbacks """

        self.interaction = Interaction()

        self.interaction.register_callback('pick', self.pick)

        self.interaction.register_callback('move', self.move)

        self.interaction.register_callback('place', self.place)

        self.interaction.register_callback('rotate_color', self.rotate_color)

        self.interaction.register_callback('scale', self.scale)
        
#######################################################################
        self.interaction.register_callback('remove', self.remove)     #
#######################################################################

#######################################################################
        self.interaction.register_callback('rotate', self.rotate)     #
#######################################################################
        
    def main_loop(self):

        glutMainLoop()



    def render(self):

        """ The render pass for the scene """

        self.init_view()



        glEnable(GL_LIGHTING)

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)



        # Load the modelview matrix from the current state of the trackball

        glMatrixMode(GL_MODELVIEW)

        glPushMatrix()

        glLoadIdentity()

        loc = self.interaction.translation

        glTranslated(loc[0], loc[1], loc[2])

        glMultMatrixf(self.interaction.trackball.matrix)



        # store the inverse of the current modelview.

        currentModelView = numpy.array(glGetFloatv(GL_MODELVIEW_MATRIX))

        self.modelView = numpy.transpose(currentModelView)

        self.inverseModelView = inv(numpy.transpose(currentModelView))



        # render the scene. This will call the render function for each object in the scene

        self.scene.render()




        # draw the grid
#######################################
        #glDisable(GL_LIGHTING)        #
                                      #
        #glCallList(G_OBJ_PLANE)       #

        #glCallList(G_OBJ_LINE)                               #
        glPopMatrix()                 #
#######################################


        # flush the buffers so that the scene can be drawn

        glFlush()



    def init_view(self):

        """ initialize the projection matrix """

        xSize, ySize = glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT)

        aspect_ratio = float(xSize) / float(ySize)



        # load the projection matrix. Always the same

        glMatrixMode(GL_PROJECTION)

        glLoadIdentity()



        glViewport(0, 0, xSize, ySize)

        gluPerspective(70, aspect_ratio, 0.1, 1000.0)

        glTranslated(0, 0, -15)



    def get_ray(self, x, y):

        """ Generate a ray beginning at the near plane, in the direction that the x, y coordinates are facing

            Consumes: x, y coordinates of mouse on screen

            Return: start, direction of the ray """

        self.init_view()



        glMatrixMode(GL_MODELVIEW)

        glLoadIdentity()



        # get two points on the line.

        start = numpy.array(gluUnProject(x, y, 0.001))

        end = numpy.array(gluUnProject(x, y, 0.999))



        # convert those points into a ray

        direction = end - start

        direction = direction / norm(direction)



        return (start, direction)



    def pick(self, x, y):

        """ Execute pick of an object. Selects an object in the scene. """

        start, direction = self.get_ray(x, y)

        #print(start, direction,x,y)
        

        self.scene.pick(start, direction, self.modelView)



    def place(self, shape, x, y):

        """ Execute a placement of a new primitive into the scene. """

        start, direction = self.get_ray(x, y)

        self.scene.place(shape, start, direction, self.inverseModelView)



    def move(self, x, y):

        """ Execute a move command on the scene. """

        start, direction = self.get_ray(x, y)


        self.scene.move_selected(start, direction, self.inverseModelView)



    def rotate_color(self, forward):

        """ Rotate the color of the selected Node. Boolean 'forward' indicates direction of rotation. """

        self.scene.rotate_selected_color(forward)



    def scale(self, up):

        """ Scale the selected Node. Boolean up indicates scaling larger."""

        self.scene.scale_selected(up)

###############################################
                                              #
    def remove(self, up):                     #
                                              #
        """ Remove the selected Node."""      #
                                              #
        self.scene.remove_selected(up)        #
###############################################

###############################################
                                              #
    def rotate(self, up):                     #
                                              #
        """ Remove the selected Node."""      #
                                              #
        self.scene.rotate_selected(up)        #
###############################################


        

if __name__ == "__main__":

    file_name = "0.png.png.mol"
    
    atom_cols_list = []

    viewer = Viewer(file_name,atom_cols_list)

    viewer.main_loop()
