# -*- coding: utf-8 -*-
# @Time : 2021/2/8 14:58
# @Author : Weiwei
# @Site :
# @File : 
# @Software: Vscode


#导入库
import csv
import time

import numpy as np
import matplotlib.pyplot as plt

import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.nn.functional as F

from rdkit import Chem
from rdkit.Chem.Crippen import MolLogP
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem.Draw import SimilarityMaps
from rdkit.Chem.Draw.MolDrawing import MolDrawing, DrawingOptions
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.Chem.rdmolops import GetAdjacencyMatrix

from help_tools import  plot_mol_with_color,get_mol_feature,get_mol_A_


max_natoms = 80
num_data = 50000


def readCSV(file_name,column_index,data_type):
    """
    读取CSV文件
    """
    CSV = csv.reader(open(file_name,'r'))
    if data_type=="str":
        data = list( map ( lambda x:  x[column_index],CSV )  )
        return data[1:]
    if data_type=="float":
        data = list( map ( lambda x:  x[column_index],CSV )  )
        data = data[1:]
        data = list( map ( lambda x: float(x),data ))
        return data


def RDkitMolLogP(smile,save_name):
    """
    计算LogP并绘图
    """
    m = Chem.MolFromSmiles(smile)
    logp = MolLogP(m)
    contribs = rdMolDescriptors._CalcCrippenContribs(m)
    atoms = m.GetNumAtoms()
    atom_list = list(range(atoms))
    atom_cols = {}
    atom_cols_list=[]
    x_with_w = np.array([x for x,y in contribs])
    x_with_w_norm = (x_with_w-x_with_w.min(0))/(x_with_w.max(0)-x_with_w.min(0))
    for index ,i in enumerate(x_with_w_norm):
        atom_cols[index] = (i,1-i,1-i)
        atom_cols_list.append([i,1-i,1-i])

    d = rdMolDraw2D.MolDraw2DCairo(500, 500)
    rdMolDraw2D.PrepareAndDrawMolecule(d,m,highlightAtoms=atom_list,highlightAtomColors=atom_cols)

    with open(save_name+".jpg", 'wb') as f:
        f.write(d.GetDrawingText())
    
    return logp



class MolDataset(Dataset):

    def __init__(self, smiles, properties, max_natoms, normalize_A=False):

      self.smiles = smiles

      self.properties = properties

      self.max_natoms = max_natoms

    def __len__(self):

        return len(self.smiles)

    def __getitem__(self, idx):

        s = self.smiles[idx]

        m = Chem.MolFromSmiles(s)

        natoms = m.GetNumAtoms()

        A = GetAdjacencyMatrix(m) + np.eye(natoms)

        A_padding = np.zeros((self.max_natoms, self.max_natoms))        

        A_padding[:natoms,:natoms] = A

        A_padding = torch.from_numpy(A_padding)
        
        #atom feature

        X = [self.atom_feature(m,i) for i in range(natoms)]

        for i in range(natoms, max_natoms):

            X.append(np.zeros(28))

        X = np.array(X)

        sample = dict()

        sample['X'] = torch.from_numpy(X)

        sample['A'] = A_padding

        sample['Y'] = self.properties[idx]

        sample["smi"] = s

        return sample

 
    def normalize_A(A):
      #D = dfadfa(A)
      #A = D*DD
      return A

 

    def one_of_k_encoding(self, x, allowable_set):

        if x not in allowable_set:

            raise Exception("input {0} not in allowable set{1}:".format(x, allowable_set))

        #print list((map(lambda s: x == s, allowable_set)))

        return list(map(lambda s: x == s, allowable_set))

 

    def one_of_k_encoding_unk(self, x, allowable_set):

        """Maps inputs not in the allowable set to the last element."""

        if x not in allowable_set:

            x = allowable_set[-1]

        return list(map(lambda s: x == s, allowable_set))

 

    def atom_feature(self, m, atom_i):

        atom = m.GetAtomWithIdx(atom_i)

        return np.array(
                        self.one_of_k_encoding_unk(atom.GetSymbol(),['C', 'N', 'O', 'S', 'F', 'P', 'Cl', 'Br', 'B', 'H']) +

                        self.one_of_k_encoding(atom.GetDegree(), [0, 1, 2, 3, 4, 5]) +

                        self.one_of_k_encoding_unk(atom.GetTotalNumHs(), [0, 1, 2, 3, 4]) +

                        self.one_of_k_encoding_unk(atom.GetImplicitValence(), [0, 1, 2, 3, 4, 5]) +

                        [atom.GetIsAromatic()])    # (10, 6, 5, 6, 1) --> total 28


#定义图卷积模型

#Model

 

class GConvRegressor(torch.nn.Module):

  def __init__(self, n_feature=128, n_layer = 10):

    super(GConvRegressor, self).__init__()

    self.W = nn.ModuleList([nn.Linear(n_feature, n_feature) for _ in range(n_layer)])

    self.embedding = nn.Linear(28, n_feature)

    self.dropout = nn.Dropout2d(0.5)

    self.fc = nn.Linear(n_feature, 1)


  def forward(self, x, A):

    x = self.embedding(x)

    for l in self.W:

      x = l(x)

      x = torch.einsum('ijk,ikl->ijl', (A.clone(), x))

      x = F.relu(x)
    
    x = x.mean(1)

    x= self.dropout(x)
    
    retval = self.fc(x)

    return retval


def train(train_smiles,train_logp,epochs):

    """
    训练模型
    """  


    lr = 1e-4
    model = GConvRegressor(128, 5) 

    #model initialize
    for param in model.parameters():
        if param.dim() == 1:
            continue
            nn.init.constant(param, 0)
        else:
            nn.init.xavier_normal_(param)

#Dataset

#载入数据



    train_dataset = MolDataset(train_smiles, train_logp, max_natoms)
    train_dataloader = DataLoader(train_dataset, batch_size=128, num_workers=0)
    #Dataloader




    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    #optimizer = torch.optim.SGD(model.parameters(), lr=lr)

    loss_fn = nn.MSELoss()
    loss_list = []

    st = time.time()
    for epoch in range(epochs):
        epoch_loss = []
        for i_batch, batch in enumerate(train_dataloader):
            x, y, A = \
                batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            pred = model(x, A).squeeze(-1)
            loss = loss_fn(pred, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)

            optimizer.step()
            loss_list.append(loss.data.cpu().numpy())
            epoch_loss.append(loss.data.cpu().numpy())

        if True: 
            print (epoch, np.mean(np.array(epoch_loss)))

    #保存模型
    #Save model
        fn = 'save-'+ str(epoch)+ '.pt'
        torch.save(model.state_dict(), fn)

    end = time.time()
    print ('Time:', end-st)
    #绘制损失曲线    
    
    plt.plot(loss_list)
    plt.xlabel('Num iteration')
    plt.ylabel('Loss')
    plt.show()




def test(test_smiles,test_logp,model_name):

    """
    测试模型性能
    """    
    #加载模型
    #Load model
    
    test_dataset = MolDataset(test_smiles, test_logp, max_natoms)
    test_dataloader = DataLoader(test_dataset, batch_size=128, num_workers=0)
    #Dataloader
    model = GConvRegressor(128, 5) 
    model.load_state_dict(torch.load(model_name))
    loss_fn = nn.MSELoss()


    #测试模型
    #Test model
    model.eval()
    with torch.no_grad():
        y_pred_train, y_pred_test = [], []
        loss_train, loss_test = [], []
        pred_train, pred_test = [], []
        true_train, true_test = [], []

        #for batch in train_dataloader:
            #x, y, A = \
                #batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            #pred = model(x, A).squeeze(-1)
            #pred_train.append(pred.data.cpu().numpy())
            #true_train.append(y.data.cpu().numpy())
            #loss_train.append(loss_fn(y, pred).data.cpu().numpy())
  
        for batch in test_dataloader:
            x, y, A = \
                batch['X'] .float(), batch['Y'] .float(), batch['A'] .float()
            #print(" x, y, A", x, y, A)
            pred = model(x, A).squeeze(-1)
            pred_test.append(pred.data.cpu().numpy())
            true_test.append(y.data.cpu().numpy())
            loss_test.append(loss_fn(y, pred).data.cpu().numpy())

    #pred_train = np.concatenate(pred_train, -1)
    pred_test = np.concatenate(pred_test, -1)
    #true_train = np.concatenate(true_train, -1)
    true_test = np.concatenate(true_test, -1)
    
    #print ('Train loss:', np.mean(np.array(loss_train)))
    print ('Test loss:', np.mean(np.array(loss_test)))

    #绘图
    plt.scatter(true_train, pred_train, s=1)
    plt.scatter(true_test, pred_test, s=1)

    plt.plot([-8,12], [-8,12])
    plt.xlabel('True')
    plt.ylabel('Pred')
    plt.show()





def predictSmiLogP(smi,model_name,save_fig_name):
    """
    获得模型热图并得到可视化结果
    """
    
    x = get_mol_feature(smi)
    A = get_mol_A_(smi)

    x_ = np.array(x).reshape([1,80,28])
    A_ = np.array(A).reshape([1,80,80])

    x_ = torch.from_numpy(x_).float()
    A_ = torch.from_numpy(A_).float()

    model = GConvRegressor(128, 5) 
    model.load_state_dict(torch.load(model_name))
    model_pred = model(x_, A_).squeeze(-1)

    fn =model_name
    model.load_state_dict(torch.load(fn))
    model.eval()
    parm = {}
    for name,parameters in model.named_parameters():  #get pytorch model parameters
        parm[name] = parameters.detach().numpy()

    x = x.dot(parm["embedding.weight"].T)+parm["embedding.bias"]
    x = A.dot(x.dot(parm["W.0.weight"].T)+parm["W.0.bias"])
    x = (abs(x) + x) / 2 #Relu
    x = A.dot(x.dot(parm["W.1.weight"].T)+parm["W.1.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.2.weight"].T)+parm["W.2.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.3.weight"].T)+parm["W.3.bias"])
    x = (abs(x) + x) / 2
    x = A.dot(x.dot(parm["W.4.weight"].T)+parm["W.4.bias"])
    x = (abs(x) + x) / 2

    x_f = x*parm["fc.weight"][0]+parm["fc.bias"][0] #80_128*128 + 1
    x_f_with_w = np.sum(x_f,1) # shape (80,)
    x_with_w = x_f_with_w
    x_with_w_norm = (x_with_w-x_with_w.min(0))/(x_with_w.max(0)-x_with_w.min(0))

    
    plot_mol_with_color(smi,x_with_w_norm,"heat_map/"+save_fig_name+".png")
    
    
    with torch.no_grad():
        x = get_mol_feature(smi)
        x = torch.from_numpy(x).float().view(1,80,28)
        A = torch.from_numpy(A).float().view(1,80,80)
      
        score = model(x, A).squeeze(-1).numpy()

        return score



    
    

if __name__ == "__main__":

    smiles =  readCSV('trainMol.csv',1,"str") # num 140000
    Y = readCSV('trainMol.csv',3,"float")

    train_smiles = smiles[:45000]
    train_logp = Y[:45000]
    epochs=30
    train(train_smiles,train_logp,epochs )

    test_smiles = smiles[45000:50000]
    test_logp = Y[45000:50000]
    model_name = 'heat_map/save-29.pt'
    test(test_smiles,test_logp,model_name)

    #smi,model_name,save_fig_name = "Cc1cc(C(=O)Nc2ccc(OCC(N)=O)cc2)c(C)n1C1CC1","save.pt","r"
    #predict_smi(smi,model_name,save_fig_name)
    #print(PRDkitMolLogP("Cc1cc(C(=O)Nc2ccc(OCC(N)=O)cc2)c(C)n1C1CC1","1"))

    smiles =  readCSV('trainMol.csv',1,"str")
    Y = readCSV('trainMol.csv',3,"float")

    for index ,smile in enumerate(smiles[-10:]):
        model_name,save_fig_name_predict,save_fig_name_RDkit = "heat_map/save-29.pt",str(index)+"r",str(index)+"t"
        LogP_GCN = predictSmiLogP(smile,model_name,save_fig_name_predict)
        LogP_RDkit = RDkitMolLogP(smile,save_fig_name_RDkit)

        print("LogP_GCN:  ",LogP_GCN,"  ","LogP_RDkit:  ",LogP_RDkit)






    
