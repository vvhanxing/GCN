# 代码介绍

* 该代码是图卷积可视化解释特征的测试代码，其主要功能是显示图卷及模型获取了分子的哪些特征做出了判断。
以预测分子油水平衡常数为例模型是否以分子的亲水基团与疏水基团为判断依据，这一代码可视化解释了这一点。
* 该部分代码处在测试阶段，完成了模型训练，模型测试，模型可视化解释基本功能代码。文件给出了训练完成一个模型参数**save-29.pt**，
可以直接生成可视化图像。解释性图像与RDKit生成的LogP分布图像作对比，衡量解释性算法的可靠性

└─chem-info  
——    └─mpnn-visual-explanation  
——————         ├─heat_map   
——————         ├─model  
——————         │      └─save  
——————         ├─pict  


# 算法原理

![image](/pict/info.PNG)

# 使用方法

python GCN_forCPU_forExplain2

```python

smi,model_name,save_fig_name = ("Cc1cc(C(=O)Nc2ccc(OCC(N)=O)cc2)c(C)n1C1CC1","save29.pt","featureMap")
predict_smi(smi,model_name,save_fig_name)

```

# 模型训练结果
## LogP回归与损失函数
![image](/pict/result.PNG)


# 可视化结果
## 解释性方法生成特征图
![image](/pict/v1.PNG)
* 图为可解释性方法给出模型的系数分布
![image](/pict/v2.PNG)
* 图为RDkit计算LogP时给出的系数分布

## 结果
* 该可解释性方法表明尽管模型只使用分子结构与LogP作为输入，却可以一定程度上学习到亲水基与亲油基分布